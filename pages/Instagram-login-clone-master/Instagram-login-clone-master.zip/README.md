# Instagram-login-clone

Simple Instagram login clone using html and css.

Check out [Live Demo](https://nikolapokrajac.github.io/Instagram-login-clone/)

### Getting Started

There are two methods for getting started with this repo.

#### Familiar with Git?

```
> git clone https://github.com/nikolaPokrajac/Instagram-login-clone.git
> cd Instagram-login-clone
> npm install
> npm start
```

#### Not Familiar with Git?

Click [here](https://github.com/nikolaPokrajac/Instagram-login-clone.git) then click on "Clone or download" and download the .zip file. Extract the contents of the zip file, then open your terminal, change to the project directory, and:

```
> npm install
> npm start
```
